#define Ntel 2 // Recources
#define Ncook 2
#define Noven 10
#define Ndeliverer 10
#define Torderlow 1 
#define Torderhigh 5
#define Norderlow 1 // Number of pizzas
#define Norderhigh 5 
#define Pm 0.35 // Chances of pizza being a margarita, pepperoni or special
#define Pp 0.25
#define Ps 0.40
#define Tpaymentlow 1 // Payment time
#define Tpaymenthigh 3
#define Pfail 0.05 // Chance of order to fail
#define Cm 10 // Pizza cost according to type of pizza
#define Cp 11
#define Cs 12
#define Tprep 1 // Prep, bake and pack time
#define Tbake 10
#define Tpack 1
#define Tdellow 5 // Delivery times
#define Tdelhigh 15
